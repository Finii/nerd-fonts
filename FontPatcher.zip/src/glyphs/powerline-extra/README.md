# Powerline Extra

For more information have a look at the upstream website: https://github.com/ryanoasis/powerline-extra-symbols

Version: 1.000 (from about 2016)

## Source modified

* Add missing Ice Waveform Mirrored glyph (0xE0CA)
* Add Trigraph Heaven glyph (0x2630)
* Simplify Waveform glyphs (0xE0C8, 0xE0CA)
* Glyph 0xE0B4 and 0xE0B6 got an additional 7% strip on their straight side.
* Add inverse triangular glyphs at 0xE0D6 and 0xE0D7
* Change version of font to 1.100

Version: 1.100 (our version)
