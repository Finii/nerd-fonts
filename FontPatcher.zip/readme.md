
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit a3cd687c5183bf51bde7341594f5a568a7c7eae7
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed Jun 26 09:59:01 2024 +0200
        
            gitlab: Small change on bug template
            
            [why]
            Make sure the examples are understood correctly and add some more info.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
